"""
database.py

This file is responsible for:
- Reading database configuration from .env file
- Creating a connection to PostgreSQL
- Providing a database session to the rest of the app
"""

import os

# Load environment variables from .env file
from dotenv import load_dotenv

# SQLAlchemy imports
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# --------------------------------------------------
# Load environment variables
# --------------------------------------------------

# This loads variables defined in the .env file into the system
load_dotenv()

# Read DATABASE_URL from .env file
DATABASE_URL = os.getenv("DATABASE_URL")

# Safety check: if DATABASE_URL is missing, stop the app
if not DATABASE_URL:
    raise ValueError("DATABASE_URL is not set in .env file")

# --------------------------------------------------
# Create SQLAlchemy engine
# --------------------------------------------------

# Engine is the main connection point to the database
engine = create_engine(
    DATABASE_URL,
    echo=True  # Prints SQL queries in terminal (very useful for beginners)
)

# --------------------------------------------------
# Create session factory
# --------------------------------------------------

# SessionLocal will be used to interact with the database
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# --------------------------------------------------
# Base class for all database models
# --------------------------------------------------

# All SQLAlchemy models will inherit from this Base
Base = declarative_base()


# --------------------------------------------------
# Dependency function (used later in FastAPI)
# --------------------------------------------------

def get_db():
    """
    This function provides a database session.
    It will be used in APIs and GraphQL resolvers.

    It:
    - Creates a new DB session
    - Yields it for use
    - Closes it after the request is done
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
