"""
models.py

This file defines all database tables using SQLAlchemy ORM.

Each class = one database table
Each class attribute = one column in the table
"""

import uuid

# SQLAlchemy imports
from sqlalchemy import Column, String, Boolean, Integer, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

# Import Base from database.py
from app.db.database import Base


# --------------------------------------------------
# Chatbot Table
# --------------------------------------------------

class Chatbot(Base):
    """
    This table stores chatbot information.
    One chatbot = one workflow.
    """

    __tablename__ = "chatbot"

    # Unique ID for each chatbot
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Chatbot name (shown to admin & user)
    name = Column(String(100), nullable=False)


# --------------------------------------------------
# Workflow Node Table
# --------------------------------------------------

class WorkflowNode(Base):
    """
    This table stores workflow nodes (cards in React Flow).

    Each node contains:
    - bot reply
    - optional user message (option text)
    - position for React Flow UI
    """

    __tablename__ = "workflow_node"

    # Unique ID for each node
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Which chatbot this node belongs to
    chatbot_id = Column(
        UUID(as_uuid=True),
        ForeignKey("chatbot.id", ondelete="CASCADE"),
        nullable=False
    )

    # Text shown as option to user (can be NULL for start node)
    user_message = Column(String, nullable=True)

    # Bot reply message (always required)
    bot_reply = Column(String, nullable=False)

    # Marks the first node of the workflow
    is_start = Column(Boolean, default=False)

    # Position of node in React Flow UI
    position_x = Column(Integer)
    position_y = Column(Integer)


# --------------------------------------------------
# Workflow Edge Table
# --------------------------------------------------

class WorkflowEdge(Base):
    """
    This table stores connections between workflow nodes.

    One node can connect to multiple nodes.
    """

    __tablename__ = "workflow_edge"

    # Unique ID for each edge
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    # Which chatbot this edge belongs to
    chatbot_id = Column(
        UUID(as_uuid=True),
        ForeignKey("chatbot.id", ondelete="CASCADE"),
        nullable=False
    )

    # Source node
    from_node_id = Column(
        UUID(as_uuid=True),
        ForeignKey("workflow_node.id", ondelete="CASCADE"),
        nullable=False
    )

    # Destination node
    to_node_id = Column(
        UUID(as_uuid=True),
        ForeignKey("workflow_node.id", ondelete="CASCADE"),
        nullable=False
    )
