"""
graphql/schema.py

This file defines:
- GraphQL Queries
- GraphQL Mutations
- Root GraphQL schema

It connects GraphQL operations to resolver functions.
"""

import strawberry
from typing import Optional

# Import GraphQL types
from app.graphql.types import (
    ChatbotType,
    WorkflowType,
    WorkflowNodeType,
    WorkflowEdgeType,
    ChatResponseType,
)

# Import resolver functions
from app.graphql.resolvers import (
    # Queries
    resolve_list_chatbots,
    resolve_get_chatbot_workflow,
    resolve_chat,

    # Mutations - Chatbot
    resolve_create_chatbot,
    resolve_rename_chatbot,
    resolve_delete_chatbot,

    # Mutations - Workflow Node
    resolve_create_node,
    resolve_update_node,
    resolve_delete_node,

    # Mutations - Workflow Edge
    resolve_create_edge,
    resolve_delete_edge,
)


# ==================================================
# QUERY DEFINITIONS
# ==================================================

@strawberry.type
class Query:
    """
    All read-only operations go here.
    """

    @strawberry.field
    def list_chatbots(self) -> list[ChatbotType]:
        """
        List all chatbots (Admin & User).
        """
        return resolve_list_chatbots()

    @strawberry.field
    def get_chatbot_workflow(self, chatbot_id: str) -> WorkflowType:
        """
        Get full workflow (nodes + edges) for a chatbot.
        """
        return resolve_get_chatbot_workflow(chatbot_id)

    @strawberry.field
    def chat(
        self,
        chatbot_id: str,
        selected_node_id: Optional[str] = None
    ) -> ChatResponseType:
        """
        User chat operation.
        """
        return resolve_chat(chatbot_id, selected_node_id)


# ==================================================
# MUTATION DEFINITIONS
# ==================================================

@strawberry.type
class Mutation:
    """
    All write operations go here.
    """

    # ---------- Chatbot mutations ----------

    @strawberry.mutation
    def create_chatbot(self, name: str) -> ChatbotType:
        return resolve_create_chatbot(name)

    @strawberry.mutation
    def rename_chatbot(self, chatbot_id: str, name: str) -> Optional[ChatbotType]:
        return resolve_rename_chatbot(chatbot_id, name)

    @strawberry.mutation
    def delete_chatbot(self, chatbot_id: str) -> bool:
        return resolve_delete_chatbot(chatbot_id)

    # ---------- Workflow Node mutations ----------

    @strawberry.mutation
    def create_node(
        self,
        chatbot_id: str,
        bot_reply: str,
        user_message: Optional[str] = None,
        is_start: bool = False,
        position_x: Optional[int] = None,
        position_y: Optional[int] = None,
    ) -> WorkflowNodeType:
        return resolve_create_node(
            chatbot_id,
            bot_reply,
            user_message,
            is_start,
            position_x,
            position_y,
        )

    @strawberry.mutation
    def update_node(
        self,
        node_id: str,
        bot_reply: Optional[str] = None,
        user_message: Optional[str] = None,
        is_start: Optional[bool] = None,
        position_x: Optional[int] = None,
        position_y: Optional[int] = None,
    ) -> Optional[WorkflowNodeType]:
        return resolve_update_node(
            node_id,
            bot_reply,
            user_message,
            is_start,
            position_x,
            position_y,
        )

    @strawberry.mutation
    def delete_node(self, node_id: str) -> bool:
        return resolve_delete_node(node_id)

    # ---------- Workflow Edge mutations ----------

    @strawberry.mutation
    def create_edge(
        self,
        chatbot_id: str,
        from_node_id: str,
        to_node_id: str,
    ) -> WorkflowEdgeType:
        return resolve_create_edge(chatbot_id, from_node_id, to_node_id)

    @strawberry.mutation
    def delete_edge(self, edge_id: str) -> bool:
        return resolve_delete_edge(edge_id)


# ==================================================
# CREATE SCHEMA
# ==================================================

schema = strawberry.Schema(
    query=Query,
    mutation=Mutation
)
