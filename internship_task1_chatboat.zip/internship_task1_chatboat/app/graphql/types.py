"""
graphql/types.py

This file defines GraphQL types.
GraphQL types describe the structure of data
that frontend can query or receive.

NO database logic should be written here.
"""

import strawberry
from typing import List, Optional


# --------------------------------------------------
# Chatbot Type
# --------------------------------------------------

@strawberry.type
class ChatbotType:
    """
    Represents a chatbot.
    Used for listing chatbots and basic chatbot info.
    """

    id: str
    name: str


# --------------------------------------------------
# Workflow Node Type
# --------------------------------------------------

@strawberry.type
class WorkflowNodeType:
    """
    Represents a workflow node (card in React Flow).
    """

    id: str
    user_message: Optional[str]
    bot_reply: str
    is_start: bool
    position_x: Optional[int]
    position_y: Optional[int]


# --------------------------------------------------
# Workflow Edge Type
# --------------------------------------------------

@strawberry.type
class WorkflowEdgeType:
    """
    Represents a connection between workflow nodes.
    """

    id: str
    from_node_id: str
    to_node_id: str


# --------------------------------------------------
# Workflow Type (Nodes + Edges)
# --------------------------------------------------

@strawberry.type
class WorkflowType:
    """
    Represents a complete workflow for a chatbot.
    """

    nodes: List[WorkflowNodeType]
    edges: List[WorkflowEdgeType]


# --------------------------------------------------
# Chat Option Type (User Side)
# --------------------------------------------------

@strawberry.type
class ChatOptionType:
    """
    Represents an option shown to the user during chat.
    """

    id: str
    user_message: Optional[str]


# --------------------------------------------------
# Chat Response Type
# --------------------------------------------------

@strawberry.type
class ChatResponseType:
    """
    Response returned by the chat query.
    """

    bot_reply: str
    options: List[ChatOptionType]
