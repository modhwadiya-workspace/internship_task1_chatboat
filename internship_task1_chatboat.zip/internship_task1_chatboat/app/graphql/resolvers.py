"""
graphql/resolvers.py

This file contains GraphQL resolver functions.
Resolvers connect GraphQL queries/mutations
to CRUD (database) operations.
"""

import uuid
from typing import List, Optional

from sqlalchemy.orm import Session

# ===============================
# REQUIRED IMPORTS (FIX)
# ===============================

# Database session
from app.db.database import SessionLocal

# CRUD imports
from app.crud.chatbot import (
    create_chatbot,
    get_all_chatbots,
    update_chatbot_name,
    delete_chatbot,
)

from app.crud.workflow import (
    create_node,
    update_node,
    delete_node,
    get_nodes_by_chatbot,
    get_edges_by_chatbot,
    create_edge,
    delete_edge,
)

from app.crud.chat import chat as chat_logic

# GraphQL types
from app.graphql.types import (
    ChatbotType,
    WorkflowNodeType,
    WorkflowEdgeType,
    WorkflowType,
    ChatOptionType,
    ChatResponseType,
)

# --------------------------------------------------
# Helper: get DB session
# --------------------------------------------------

def get_db_session() -> Session:
    """
    Create and return a database session.
    """
    return SessionLocal()


# ==================================================
# QUERY RESOLVERS
# ==================================================

def resolve_list_chatbots() -> List[ChatbotType]:
    """
    List all chatbots (Admin & User).
    """
    db = get_db_session()
    try:
        chatbots = get_all_chatbots(db)
        return [
            ChatbotType(id=str(bot.id), name=bot.name)
            for bot in chatbots
        ]
    finally:
        db.close()


def resolve_get_chatbot_workflow(chatbot_id: str) -> WorkflowType:
    """
    Fetch full workflow (nodes + edges) for a chatbot.
    """
    db = get_db_session()
    try:
        chatbot_uuid = uuid.UUID(chatbot_id)

        nodes = get_nodes_by_chatbot(db, chatbot_uuid)
        edges = get_edges_by_chatbot(db, chatbot_uuid)

        return WorkflowType(
            nodes=[
                WorkflowNodeType(
                    id=str(node.id),
                    user_message=node.user_message,
                    bot_reply=node.bot_reply,
                    is_start=node.is_start,
                    position_x=node.position_x,
                    position_y=node.position_y,
                )
                for node in nodes
            ],
            edges=[
                WorkflowEdgeType(
                    id=str(edge.id),
                    from_node_id=str(edge.from_node_id),
                    to_node_id=str(edge.to_node_id),
                )
                for edge in edges
            ],
        )
    finally:
        db.close()


def resolve_chat(
    chatbot_id: str,
    selected_node_id: Optional[str] = None
) -> ChatResponseType:
    """
    User chat operation.
    """
    db = get_db_session()
    try:
        chatbot_uuid = uuid.UUID(chatbot_id)
        node_uuid = uuid.UUID(selected_node_id) if selected_node_id else None

        result = chat_logic(db, chatbot_uuid, node_uuid)

        return ChatResponseType(
            bot_reply=result["bot_reply"],
            options=[
                ChatOptionType(
                    id=str(opt.id),
                    user_message=opt.user_message
                )
                for opt in result["options"]
            ]
        )
    finally:
        db.close()


# ==================================================
# MUTATION RESOLVERS (ADMIN)
# ==================================================

def resolve_create_chatbot(name: str) -> ChatbotType:
    """
    Create a new chatbot.
    """
    db = get_db_session()
    try:
        chatbot = create_chatbot(db, name)
        return ChatbotType(id=str(chatbot.id), name=chatbot.name)
    finally:
        db.close()


def resolve_rename_chatbot(chatbot_id: str, name: str) -> Optional[ChatbotType]:
    """
    Rename an existing chatbot.
    """
    db = get_db_session()
    try:
        chatbot = update_chatbot_name(db, uuid.UUID(chatbot_id), name)
        if not chatbot:
            return None

        return ChatbotType(id=str(chatbot.id), name=chatbot.name)
    finally:
        db.close()


def resolve_delete_chatbot(chatbot_id: str) -> bool:
    """
    Delete a chatbot.
    """
    db = get_db_session()
    try:
        return delete_chatbot(db, uuid.UUID(chatbot_id))
    finally:
        db.close()


def resolve_create_node(
    chatbot_id: str,
    bot_reply: str,
    user_message: Optional[str] = None,
    is_start: bool = False,
    position_x: Optional[int] = None,
    position_y: Optional[int] = None,
) -> WorkflowNodeType:
    """
    Create a workflow node.
    """
    db = get_db_session()
    try:
        node = create_node(
            db=db,
            chatbot_id=uuid.UUID(chatbot_id),
            bot_reply=bot_reply,
            user_message=user_message,
            is_start=is_start,
            position_x=position_x,
            position_y=position_y,
        )

        return WorkflowNodeType(
            id=str(node.id),
            user_message=node.user_message,
            bot_reply=node.bot_reply,
            is_start=node.is_start,
            position_x=node.position_x,
            position_y=node.position_y,
        )
    finally:
        db.close()


def resolve_update_node(
    node_id: str,
    bot_reply: Optional[str] = None,
    user_message: Optional[str] = None,
    is_start: Optional[bool] = None,
    position_x: Optional[int] = None,
    position_y: Optional[int] = None,
) -> Optional[WorkflowNodeType]:
    """
    Update a workflow node.
    """
    db = get_db_session()
    try:
        node = update_node(
            db=db,
            node_id=uuid.UUID(node_id),
            bot_reply=bot_reply,
            user_message=user_message,
            is_start=is_start,
            position_x=position_x,
            position_y=position_y,
        )

        if not node:
            return None

        return WorkflowNodeType(
            id=str(node.id),
            user_message=node.user_message,
            bot_reply=node.bot_reply,
            is_start=node.is_start,
            position_x=node.position_x,
            position_y=node.position_y,
        )
    finally:
        db.close()


def resolve_delete_node(node_id: str) -> bool:
    """
    Delete a workflow node.
    """
    db = get_db_session()
    try:
        return delete_node(db, uuid.UUID(node_id))
    finally:
        db.close()


def resolve_create_edge(
    chatbot_id: str,
    from_node_id: str,
    to_node_id: str,
) -> WorkflowEdgeType:
    """
    Create a workflow edge.
    """
    db = get_db_session()
    try:
        edge = create_edge(
            db=db,
            chatbot_id=uuid.UUID(chatbot_id),
            from_node_id=uuid.UUID(from_node_id),
            to_node_id=uuid.UUID(to_node_id),
        )

        return WorkflowEdgeType(
            id=str(edge.id),
            from_node_id=str(edge.from_node_id),
            to_node_id=str(edge.to_node_id),
        )
    finally:
        db.close()


def resolve_delete_edge(edge_id: str) -> bool:
    """
    Delete a workflow edge.
    """
    db = get_db_session()
    try:
        return delete_edge(db, uuid.UUID(edge_id))
    finally:
        db.close()
