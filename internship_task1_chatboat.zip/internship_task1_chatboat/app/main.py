"""
main.py

This is the main entry point of the backend application.

Responsibilities:
1. Create FastAPI app
2. Initialize database tables
3. Expose GraphQL endpoint
4. Provide a simple health check endpoint
"""

# ----------------------------------------
# FastAPI imports
# ----------------------------------------
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware  # ✅ FIX

# ----------------------------------------
# GraphQL (Strawberry) import
# ----------------------------------------
from strawberry.fastapi import GraphQLRouter

# ----------------------------------------
# Database imports
# ----------------------------------------
from app.db.database import engine, Base

# IMPORTANT:
# Importing models ensures SQLAlchemy knows
# about all tables before creating them
from app.db import models  # noqa: F401

# ----------------------------------------
# GraphQL schema import
# ----------------------------------------
from app.graphql.schema import schema


# ----------------------------------------
# Create FastAPI application
# ----------------------------------------
app = FastAPI(
    title="Workflow Based Chatbot Backend",
    description="Backend for a workflow-driven chatbot platform",
    version="1.0.0",
)


# ----------------------------------------
# CORS CONFIGURATION (REQUIRED FOR FRONTEND)
# ----------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",  # Next.js frontend
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ----------------------------------------
# Create database tables
# ----------------------------------------
# Safe to run multiple times
Base.metadata.create_all(bind=engine)

# ----------------------------------------
# Setup GraphQL endpoint
# ----------------------------------------
graphql_app = GraphQLRouter(schema)
app.include_router(graphql_app, prefix="/graphql")


# ----------------------------------------
# Health check endpoint
# ----------------------------------------
@app.get("/")
def root():
    """
    Simple endpoint to check if the backend is running.
    """
    return {
        "status": "Backend + Database + GraphQL are running successfully ✅ 🌳🌳"
    }
