"""
crud/workflow.py

This file contains database operations related to:
- Workflow Nodes (cards)
- Workflow Edges (connections)

This logic is used by Admin to design chatbot workflows.
"""

import uuid
from sqlalchemy.orm import Session

from app.db.models import WorkflowNode, WorkflowEdge


# ==================================================
# WORKFLOW NODE OPERATIONS
# ==================================================

def create_node(
    db: Session,
    chatbot_id: uuid.UUID,
    bot_reply: str,
    user_message: str | None = None,
    is_start: bool = False,
    position_x: int | None = None,
    position_y: int | None = None,
):
    """
    Create a new workflow node (card).
    """

    # If this node is marked as start,
    # ensure no other start node exists for this chatbot
    if is_start:
        db.query(WorkflowNode).filter(
            WorkflowNode.chatbot_id == chatbot_id,
            WorkflowNode.is_start == True
        ).update({"is_start": False})

    node = WorkflowNode(
        id=uuid.uuid4(),
        chatbot_id=chatbot_id,
        user_message=user_message,
        bot_reply=bot_reply,
        is_start=is_start,
        position_x=position_x,
        position_y=position_y
    )

    db.add(node)
    db.commit()
    db.refresh(node)

    return node


def get_nodes_by_chatbot(db: Session, chatbot_id: uuid.UUID):
    """
    Fetch all nodes belonging to a chatbot.
    """

    return db.query(WorkflowNode).filter(
        WorkflowNode.chatbot_id == chatbot_id
    ).all()


def get_node_by_id(db: Session, node_id: uuid.UUID):
    """
    Fetch a single node by ID.
    """

    return db.query(WorkflowNode).filter(
        WorkflowNode.id == node_id
    ).first()


def update_node(
    db: Session,
    node_id: uuid.UUID,
    bot_reply: str | None = None,
    user_message: str | None = None,
    is_start: bool | None = None,
    position_x: int | None = None,
    position_y: int | None = None,
):
    """
    Update an existing workflow node.
    """

    node = get_node_by_id(db, node_id)

    if not node:
        return None

    # Update fields only if values are provided
    if bot_reply is not None:
        node.bot_reply = bot_reply

    if user_message is not None:
        node.user_message = user_message

    if position_x is not None:
        node.position_x = position_x

    if position_y is not None:
        node.position_y = position_y

    if is_start is not None:
        # Ensure only one start node exists per chatbot
        if is_start:
            db.query(WorkflowNode).filter(
                WorkflowNode.chatbot_id == node.chatbot_id,
                WorkflowNode.is_start == True
            ).update({"is_start": False})

        node.is_start = is_start

    db.commit()
    db.refresh(node)

    return node


def delete_node(db: Session, node_id: uuid.UUID) -> bool:
    """
    Delete a workflow node.
    All related edges will be deleted automatically (CASCADE).
    """

    node = get_node_by_id(db, node_id)

    if not node:
        return False

    db.delete(node)
    db.commit()

    return True


# ==================================================
# WORKFLOW EDGE OPERATIONS
# ==================================================

def create_edge(
    db: Session,
    chatbot_id: uuid.UUID,
    from_node_id: uuid.UUID,
    to_node_id: uuid.UUID,
):
    """
    Create a connection between two workflow nodes.
    """

    edge = WorkflowEdge(
        id=uuid.uuid4(),
        chatbot_id=chatbot_id,
        from_node_id=from_node_id,
        to_node_id=to_node_id
    )

    db.add(edge)
    db.commit()
    db.refresh(edge)

    return edge


def get_edges_by_chatbot(db: Session, chatbot_id: uuid.UUID):
    """
    Fetch all edges belonging to a chatbot.
    """

    return db.query(WorkflowEdge).filter(
        WorkflowEdge.chatbot_id == chatbot_id
    ).all()


def delete_edge(db: Session, edge_id: uuid.UUID) -> bool:
    """
    Delete a workflow edge.
    """

    edge = db.query(WorkflowEdge).filter(
        WorkflowEdge.id == edge_id
    ).first()

    if not edge:
        return False

    db.delete(edge)
    db.commit()

    return True
