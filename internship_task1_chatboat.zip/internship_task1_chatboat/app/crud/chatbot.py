"""
crud/chatbot.py

This file contains all database operations related to Chatbot.
These functions will be used by GraphQL resolvers later.
"""

import uuid
from sqlalchemy.orm import Session

from app.db.models import Chatbot


# --------------------------------------------------
# Create a new chatbot
# --------------------------------------------------

def create_chatbot(db: Session, name: str) -> Chatbot:
    """
    Create a new chatbot with the given name.
    """

    chatbot = Chatbot(
        id=uuid.uuid4(),
        name=name
    )

    db.add(chatbot)     # add to DB session
    db.commit()         # save to database
    db.refresh(chatbot) # refresh object with DB data

    return chatbot


# --------------------------------------------------
# Get all chatbots
# --------------------------------------------------

def get_all_chatbots(db: Session):
    """
    Fetch all chatbots from the database.
    """

    return db.query(Chatbot).all()


# --------------------------------------------------
# Get chatbot by ID
# --------------------------------------------------

def get_chatbot_by_id(db: Session, chatbot_id: uuid.UUID):
    """
    Fetch a single chatbot by its ID.
    """

    return db.query(Chatbot).filter(Chatbot.id == chatbot_id).first()


# --------------------------------------------------
# Update chatbot name
# --------------------------------------------------

def update_chatbot_name(db: Session, chatbot_id: uuid.UUID, new_name: str):
    """
    Update the name of an existing chatbot.
    """

    chatbot = get_chatbot_by_id(db, chatbot_id)

    if not chatbot:
        return None

    chatbot.name = new_name
    db.commit()
    db.refresh(chatbot)

    return chatbot


# --------------------------------------------------
# Delete chatbot
# --------------------------------------------------

def delete_chatbot(db: Session, chatbot_id: uuid.UUID) -> bool:
    """
    Delete a chatbot by ID.
    Related nodes and edges will be deleted automatically (CASCADE).
    """

    chatbot = get_chatbot_by_id(db, chatbot_id)

    if not chatbot:
        return False

    db.delete(chatbot)
    db.commit()

    return True
