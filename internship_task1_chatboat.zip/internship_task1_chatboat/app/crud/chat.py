"""
crud/chat.py

This file contains the chat traversal logic.
It decides:
- Which bot reply to return
- Which options (next nodes) to show

This is the core logic of the chatbot.
"""

import uuid
from sqlalchemy.orm import Session

from app.db.models import WorkflowNode, WorkflowEdge


# --------------------------------------------------
# Helper: get start node
# --------------------------------------------------

def get_start_node(db: Session, chatbot_id: uuid.UUID):
    """
    Fetch the start node for a chatbot.
    """

    return db.query(WorkflowNode).filter(
        WorkflowNode.chatbot_id == chatbot_id,
        WorkflowNode.is_start == True
    ).first()


# --------------------------------------------------
# Helper: get child nodes (options)
# --------------------------------------------------

def get_child_nodes(db: Session, node_id: uuid.UUID):
    """
    Fetch all child nodes connected from a given node.
    These are shown as options to the user.
    """

    edges = db.query(WorkflowEdge).filter(
        WorkflowEdge.from_node_id == node_id
    ).all()

    # Extract destination node IDs
    child_node_ids = [edge.to_node_id for edge in edges]

    if not child_node_ids:
        return []

    return db.query(WorkflowNode).filter(
        WorkflowNode.id.in_(child_node_ids)
    ).all()


# --------------------------------------------------
# Main chat logic
# --------------------------------------------------

def chat(
    db: Session,
    chatbot_id: uuid.UUID,
    selected_node_id: uuid.UUID | None = None
):
    """
    Main chat logic.

    Rules:
    - If selected_node_id is None → return start node
    - If selected_node_id exists → return that node
    - If anything fails → fallback to start node
    """

    current_node = None

    # Case 1: user selected an option
    if selected_node_id:
        current_node = db.query(WorkflowNode).filter(
            WorkflowNode.id == selected_node_id,
            WorkflowNode.chatbot_id == chatbot_id
        ).first()

    # Case 2: fallback to start node
    if not current_node:
        current_node = get_start_node(db, chatbot_id)

    # Safety check: chatbot has no start node
    if not current_node:
        return {
            "bot_reply": "Chatbot is not configured properly.",
            "options": []
        }

    # Get options (child nodes)
    options = get_child_nodes(db, current_node.id)

    return {
        "bot_reply": current_node.bot_reply,
        "options": options
    }
